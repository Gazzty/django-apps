from django.contrib import admin
from .models import Link

# Register your models here.
class LinkAdmin(admin.ModelAdmin):
    readonly_fields = ('created', 'updated')
    
    # Add roles for group 'Personal', so they don't edit the key word for social media
    def get_readonly_fields(self, request, obj=None):
        if request.user.groups.filter(name="Personal").exists():
            return ('created', 'updated', 'key', 'name')
        else:
            return ('created', 'updated')
    # Use get_exclude for hiding fields
    
admin.site.register(Link, LinkAdmin)