from django.contrib import admin
from .models import Post, Category

# Register your models here.
class CategoryAdmin(admin.ModelAdmin):
    readonly_fields = ('created', 'updated')
class PostAdmin(admin.ModelAdmin):
    readonly_fields = ('created', 'updated')
    list_display = ('title', 'author', 'published', 'post_categories')
    ordering = ('published', 'author')
    # Can add more fields, users have multiple fields, that's why they need an specific field
    search_fields = ('title', 'content', 'author__username')
    date_hierarchy = 'published'
    list_filter = ('published', 'author__username', 'categories__name')
    
    # Function for adding category in admin list
    # obj is the object, in this case the Post
    def post_categories(self, post):
        return ', '.join(c.name for c in post.categories.all().order_by('name'))
    post_categories.short_description = 'Categorias'
    
admin.site.register(Category, CategoryAdmin)
admin.site.register(Post, PostAdmin)