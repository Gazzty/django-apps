from django.shortcuts import render
from .models import Services

# Create your views here.
def servicesView(request):
    context = {
        'services': Services.objects.all()
    }
    return render(request, 'services/services.html', context)    