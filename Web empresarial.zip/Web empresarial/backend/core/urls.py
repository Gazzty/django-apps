from django.urls import path
from . import views as core_views

urlpatterns = [
    path('', core_views.homeView, name='home'),
    path('about/', core_views.aboutView, name='about'),
    path('store/', core_views.storeView, name='store'),
]
