from django.shortcuts import render, HttpResponse

# Create your views here.
def homeView(request):
    return render(request, 'core/index.html')

def aboutView(request):
    return render(request, 'core/about.html')

def servicesView(request):
    return render(request, 'core/services.html')

def storeView(request):
    return render(request, 'core/store.html')