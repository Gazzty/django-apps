from django import forms


class ContactForm(forms.Form):
    name = forms.CharField(required=True, label='Nombre', widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': 'Nombre'}
    ))
    email = forms.EmailField(required=True, label='Email', widget=forms.EmailInput(
        attrs={'class': 'form-control', 'placeholder': 'Mail'}
    ))
    content = forms.CharField(required=True, label='Contenido', widget=forms.Textarea(
        attrs={'class': 'form-control', 'rows': 3,
               'placeholder': 'Escribe tu mensaje'}
    ))
