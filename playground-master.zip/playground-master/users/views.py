from pyexpat.errors import messages
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm  
from django.contrib.auth import get_user_model, logout

# Create your views here.
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            """ messages.success(request, 'Account created')  NOT WORKING """
            return redirect('list-users')   #Se pone el nombre de la URL
    
    else:
        form = UserCreationForm()
    context = {
        'form': form
    }
    return render(request, 'users/register.html', context)

def listUsers(request):
    User = get_user_model()
    users = User.objects.all()
    context = {
        'users': users
    }
    return render(request, 'users/list.html', context)

def loginView(request):
    return render(request, 'users/login.html')
def logoutView(request):
    logout(request)
    return render(request, 'users/logout.html')

def profileView(request, id):
    User = get_user_model()
    user = User.objects.get(id=id)
    return render(request, 'users/check-login.html', context={'user':user})

def deleteUserView(request, id):
    User = get_user_model()
    user = User.objects.get(id=id)
    user.delete()
    return redirect('list-users')