from django.urls import path, include
from .views import *

urlpatterns = [
    path('register/', register, name='register'),
    path('list/', listUsers, name='list-users'),
    path('accounts/', include('django.contrib.auth.urls'), name='login'),
    path('accounts/profile/', profileView, name='profile'),
    path('delete/<int:id>', deleteUserView, name='delete'),
]
