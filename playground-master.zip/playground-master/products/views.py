from django.shortcuts import render, redirect
from .models import Product
from .forms import createProductForm


# Create your views here.
def productView(request):
    products = Product.objects.all()
    context = {
        'products': products
    }
    return render(request, 'products/list.html', context)

def createProduct(request):
    if request.method == 'POST':
        form = createProductForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect(productView)
    return render(request, 'products/create.html', {'form':createProductForm})

def deleteProduct(request, id):
    product = Product.objects.get(id=id)
    product.delete()
    return redirect(productView)