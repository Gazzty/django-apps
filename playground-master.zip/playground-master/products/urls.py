from django.urls import path
from .views import *

urlpatterns = [
    path('list/', productView, name='product-list'),
    path('create/', createProduct, name='product-create'),
    path('delete/<int:id>', deleteProduct, name='product-delete'),
]
