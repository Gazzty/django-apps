from typing_extensions import Required
from django.forms import ModelForm
from django import forms
from .models import Product

class createProductForm(ModelForm):
    title = forms.TextInput()
    quantity = forms.IntegerField(required=False)
    price = forms.FloatField(required=False)

    class Meta:
        model = Product
        fields = ['title','quantity','price']