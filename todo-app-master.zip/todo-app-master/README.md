# todo-app
To do app with django

To run the app you have to install django, enter the backend folder and run "py manage.py runserver".
